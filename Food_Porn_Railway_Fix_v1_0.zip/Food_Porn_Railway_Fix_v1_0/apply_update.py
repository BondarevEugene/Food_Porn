"""
==========================================================
FOOD_PORN

Module: Railway Deployment Fix Installer
Layer: Developer Tooling

Responsibilities:
    - Validate the Food_Porn project root
    - Back up every replaced file
    - Install the Railway bootstrap and dependency fixes
    - Leave an auditable list of changed files
==========================================================
"""

from __future__ import annotations

import argparse
import shutil
from datetime import UTC, datetime
from pathlib import Path

UPDATE_NAME = "railway_fix_v1_0"
PAYLOAD_ROOT = Path(__file__).resolve().parent / "payload"

FILES = (
    ".dockerignore",
    "requirements.txt",
    "main.py",
    "app/admin_app.py",
    "app/bot/handlers/admin.py",
    "app/config.py",
    "tests/test_config.py",
    "tests/test_railway_bootstrap.py",
)

PROJECT_MARKERS = (
    "Dockerfile",
    "launcher.py",
    "main.py",
    "app/admin_app.py",
    "app/config.py",
)


def validate_project(project: Path) -> None:
    missing = [name for name in PROJECT_MARKERS if not (project / name).is_file()]
    if missing:
        raise SystemExit(
            "ERROR: This is not the Food_Porn project root. Missing: " + ", ".join(missing)
        )

    missing_payload = [name for name in FILES if not (PAYLOAD_ROOT / name).is_file()]
    if missing_payload:
        raise SystemExit("ERROR: Update package is incomplete: " + ", ".join(missing_payload))


def install(project: Path) -> Path:
    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    backup_root = project / "_backups" / f"{UPDATE_NAME}_{timestamp}"

    for relative_name in FILES:
        source = PAYLOAD_ROOT / relative_name
        target = project / relative_name

        if target.is_file():
            backup = backup_root / relative_name
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)

        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    return backup_root


def main() -> None:
    parser = argparse.ArgumentParser(description="Install the Food_Porn Railway deployment fix")
    parser.add_argument("--project", default=".", help="Food_Porn project root")
    parser.add_argument("--apply", action="store_true", help="Apply changes after validation")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    validate_project(project)

    print("FOOD_PORN · RAILWAY FIX v1.0")
    print(f"Project: {project}")
    print(f"Files:   {len(FILES)}")

    if not args.apply:
        print("VALIDATION OK · No files changed. Add --apply to install.")
        return

    backup_root = install(project)
    print("INSTALLATION OK")
    print(f"Backup:  {backup_root}")
    print("Next: python -m pytest -q")
    print("Then: git add . && git commit -m 'Fix Railway deployment' && git push")


if __name__ == "__main__":
    main()
