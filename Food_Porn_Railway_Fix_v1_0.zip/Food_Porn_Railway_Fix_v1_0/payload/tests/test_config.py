"""
==========================================================
FOOD_PORN

Module: Configuration Tests
Layer: Test

Responsibilities:
    - Verify optional administrator ID parsing
    - Verify safe OpenAI request defaults
==========================================================
"""

from app.config import Settings


def test_empty_admin_ids_from_env_is_allowed(monkeypatch) -> None:
    monkeypatch.setenv("ADMIN_TELEGRAM_IDS", "")
    settings = Settings(_env_file=None)
    assert settings.admin_telegram_ids == ()


def test_comma_separated_admin_ids_from_env(monkeypatch) -> None:
    monkeypatch.setenv("ADMIN_TELEGRAM_IDS", "123, 456")
    settings = Settings(_env_file=None)
    assert settings.admin_telegram_ids == (123, 456)


def test_json_admin_ids_from_env(monkeypatch) -> None:
    monkeypatch.setenv("ADMIN_TELEGRAM_IDS", "[]")
    assert Settings(_env_file=None).admin_telegram_ids == ()

    monkeypatch.setenv("ADMIN_TELEGRAM_IDS", "[123, 456]")
    assert Settings(_env_file=None).admin_telegram_ids == (123, 456)


def test_free_generation_ids_are_separate_from_admin_access(monkeypatch) -> None:
    monkeypatch.setenv("FREE_GENERATION_TELEGRAM_IDS", "725003786, 42")
    settings = Settings(_env_file=None)
    assert settings.free_generation_telegram_ids == (725003786, 42)
    assert settings.admin_telegram_ids == ()


def test_safe_image_request_defaults() -> None:
    settings = Settings(_env_file=None)
    assert settings.image_concurrency == 1
    assert settings.image_retries == 2
    assert settings.openai_quota_cooldown_seconds == 300


def test_neon_url_is_normalized_for_asyncpg(monkeypatch) -> None:
    monkeypatch.setenv(
        "DATABASE_URL",
        "postgresql://owner:secret@example.neon.tech/neondb"
        "?sslmode=require&channel_binding=require",
    )

    url = Settings(_env_file=None).database_url

    assert url.startswith("postgresql+asyncpg://")
    assert "ssl=require" in url
    assert "sslmode" not in url
    assert "channel_binding" not in url
