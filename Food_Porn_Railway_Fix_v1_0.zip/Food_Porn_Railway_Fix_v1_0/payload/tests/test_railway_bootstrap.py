"""
==========================================================
FOOD_PORN

Module: Railway Bootstrap Tests
Layer: Quality Assurance

Responsibilities:
    - Verify one canonical FastAPI application
    - Verify Mini App and payment routes survive admin mounting
    - Verify the Railway healthcheck endpoint is registered
==========================================================
"""

from main import app


def test_canonical_application_contains_public_routes() -> None:
    paths = {route.path for route in app.routes if hasattr(route, "path")}
    for route in app.routes:
        included = getattr(route, "original_router", None)
        if included is not None:
            paths.update(child.path for child in included.routes if hasattr(child, "path"))

    assert "/health" in paths
    assert "/miniapp" in paths
    assert "/miniapp/api/home" in paths
    assert "/portmone/callback" in paths
    assert "/admin" in paths
