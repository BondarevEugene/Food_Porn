# Food_Porn — исправление публикации на Railway

Пакет подготовлен для актуального состояния репозитория `BondarevEugene/Food_Porn`, commit `63638bc08439e0e5b9fe399f72acb8eefb1cd84f`.

## Почему приложение падало

Строка `main.py:50` импортировала `app.admin_app`. Во время этого импорта возникала цепочка проблем:

1. админ-панель загружала корневой `config.py`, который не переводил Neon URL на драйвер `asyncpg` — результатом мог быть `No module named psycopg2`;
2. SQLAdmin использует сессии Starlette, но пакет `itsdangerous` отсутствовал в `requirements.txt`;
3. импорт подменял главное FastAPI-приложение приложением админки, поэтому Mini App и платежные маршруты терялись;
4. приложение слушало фиксированный порт вместо Railway-переменной `PORT`.

## Что исправлено

- добавлен `itsdangerous`;
- админка использует единый `app.config`;
- Neon URL автоматически преобразуется в `postgresql+asyncpg://`;
- `sslmode=require` преобразуется в совместимый `ssl=require`;
- удаляется несовместимый параметр Neon `channel_binding`;
- используется одно FastAPI-приложение для админки, Mini App и платежей;
- сервер читает порт из переменной Railway `PORT`;
- добавлен endpoint `/health`;
- добавлен `.dockerignore`, исключающий локальные venv, резервные копии и пользовательские файлы;
- исправлена проверка Telegram-администратора и импорт рассылки.

## Установка в PowerShell

Остановите локальный бот клавишами `Ctrl+C`, затем перейдите в проект:

```powershell
cd C:\Users\bonda\PycharmProjects\Food_Porn
```

Распакуйте скачанный ZIP в `Downloads`, найдите установщик и примените обновление:

```powershell
$railwayZip = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter "Food_Porn_Railway_Fix_v1_0*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
```

```powershell
$railwayDir = "$env:USERPROFILE\Downloads\Food_Porn_Railway_Update"
```

```powershell
Expand-Archive -LiteralPath $railwayZip.FullName -DestinationPath $railwayDir -Force
```

```powershell
$railwayInstaller = Get-ChildItem $railwayDir -Recurse -File -Filter apply_update.py | Select-Object -First 1
```

Проверка без изменения файлов:

```powershell
python $railwayInstaller.FullName --project (Get-Location).Path
```

Установка:

```powershell
python $railwayInstaller.FullName --project (Get-Location).Path --apply
```

Установщик создаст резервную копию в `_backups\railway_fix_v1_0_...`.

## Локальная проверка и отправка на GitHub

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q
python -m ruff check main.py app/admin_app.py app/config.py app/bot/handlers/admin.py tests/test_config.py tests/test_railway_bootstrap.py
```

Ожидаемый результат тестов:

```text
94 passed
```

Затем отправьте изменения в GitHub:

```powershell
git add .
git commit -m "Fix Railway deployment bootstrap"
git push origin master
```

Railway автоматически начнёт новый deployment из GitHub.

## Настройка Railway

### Variables

Добавьте в Railway → ваш сервис → `Variables`:

```text
APP_ENV=production
BOT_TOKEN=ваш_токен_BotFather
DATABASE_URL=ваша_строка_Neon
OPENAI_API_KEY=ваш_новый_ключ_OpenAI
ADMIN_USERNAME=ваш_логин
ADMIN_PASSWORD=сложный_пароль
ADMIN_SESSION_SECRET=случайная_длинная_строка
STORAGE_ROOT=/data/storage
```

Не добавляйте пробел после `=` и не заключайте значения в кавычки.

Секрет для `ADMIN_SESSION_SECRET` можно создать локально:

```powershell
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Переменную `PORT` вручную создавать не нужно: Railway передаёт её приложению автоматически.

### Deploy

В Railway → `Settings` → `Deploy`:

- Start Command: оставьте пустым, чтобы использовался Dockerfile, или укажите `python run.py`;
- Pre-deploy Command: `python -m alembic upgrade head`;
- Healthcheck Path: `/health`;
- Healthcheck Timeout: `300`;
- Replicas: строго `1`, потому что Telegram long polling с одним токеном нельзя одновременно запускать в нескольких процессах.

### Networking

В `Settings` → `Networking` нажмите `Generate Domain`. После получения адреса добавьте или обновите переменную:

```text
MINIAPP_URL=https://ВАШ-ДОМЕН.up.railway.app/miniapp
```

После изменения переменной выполните Redeploy.

### Volume

Добавьте Railway Volume с Mount Path:

```text
/data
```

Без Volume загруженные фотографии и готовые PDF будут удаляться при каждом redeploy. Переменная `STORAGE_ROOT=/data/storage` направляет файлы на подключённый Volume.

## Проверка после публикации

Откройте:

```text
https://ВАШ-ДОМЕН.up.railway.app/health
```

Ожидаемый ответ:

```json
{"status":"ok","service":"food-porn"}
```

Затем отправьте `/start` боту именно в Telegram.

Перед запуском Railway обязательно остановите локальный экземпляр бота в PyCharm. Иначе Telegram выдаст конфликт двух polling-процессов.

## Важная безопасность

Не публикуйте `.env`, BOT_TOKEN, DATABASE_URL и OPENAI_API_KEY в GitHub или сообщениях. Если ключ когда-либо был показан публично, отзовите его и создайте новый.
