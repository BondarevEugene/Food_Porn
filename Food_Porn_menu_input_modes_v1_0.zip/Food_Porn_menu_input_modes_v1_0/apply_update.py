"""
==========================================================
FOOD_PORN

Module: Menu Input Modes Update Installer
Layer: Developer Tooling

Responsibilities:
    - Validate the target Food_Porn project
    - Back up every file before replacement
    - Install the structured and free-list menu modes
    - Print clear post-install verification commands
==========================================================
"""

from __future__ import annotations

import argparse
import shutil
from datetime import UTC, datetime
from pathlib import Path

UPDATE_NAME = "menu_input_modes_v1_0"
PAYLOAD_ROOT = Path(__file__).resolve().parent / "payload"

FILES = (
    "app/bot/handlers/menu.py",
    "app/bot/handlers/start.py",
    "app/miniapp/api.py",
    "app/miniapp/static/app.js",
    "app/miniapp/static/index.html",
    "app/miniapp/static/style.css",
    "app/services/dish_input.py",
    "tests/test_dish_input.py",
)

PROJECT_MARKERS = (
    "launcher.py",
    "app/database/models.py",
    "app/miniapp/api.py",
    "app/bot/handlers/menu.py",
)


def validate_project(project: Path) -> None:
    missing = [name for name in PROJECT_MARKERS if not (project / name).is_file()]
    if missing:
        rendered = ", ".join(missing)
        raise SystemExit(f"ERROR: This is not the Food_Porn project root. Missing: {rendered}")

    missing_payload = [name for name in FILES if not (PAYLOAD_ROOT / name).is_file()]
    if missing_payload:
        rendered = ", ".join(missing_payload)
        raise SystemExit(f"ERROR: Update package is incomplete. Missing: {rendered}")


def install(project: Path) -> Path:
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    backup_root = project / "_backups" / f"{UPDATE_NAME}_{stamp}"

    for relative_name in FILES:
        source = PAYLOAD_ROOT / relative_name
        target = project / relative_name
        if target.is_file():
            backup = backup_root / relative_name
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)

        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    return backup_root


def main() -> None:
    parser = argparse.ArgumentParser(description="Install two menu input modes into Food_Porn")
    parser.add_argument("--project", default=".", help="Path to the Food_Porn project root")
    parser.add_argument("--apply", action="store_true", help="Apply the update; otherwise only validate")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    validate_project(project)

    print("FOOD_PORN · MENU INPUT MODES v1.0")
    print(f"Project: {project}")
    print(f"Files:   {len(FILES)}")

    if not args.apply:
        print("VALIDATION OK · No files changed. Add --apply to install.")
        return

    backup_root = install(project)
    print("INSTALLATION OK")
    print(f"Backup:  {backup_root}")
    print("Next: python -m pytest tests/test_dish_input.py tests/test_menu_plan.py -q")
    print("Run:  python -u launcher.py start")


if __name__ == "__main__":
    main()
