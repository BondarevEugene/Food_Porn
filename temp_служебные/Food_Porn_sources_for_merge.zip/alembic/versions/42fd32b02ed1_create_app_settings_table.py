"""create_app_settings_table

Revision ID: 42fd32b02ed1
Revises: 226c0d2b7f58
Create Date: 2026-09-26 11:55:49.292073
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '42fd32b02ed1'
down_revision: Union[str, None] = '226c0d2b7f58'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

