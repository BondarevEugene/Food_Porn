"""add_payment_columns_to_menu

Revision ID: 226c0d2b7f58
Revises: 20260918_0002
Create Date: 2026-09-24 23:43:46.302629
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = '226c0d2b7f58'
down_revision: str | None = '20260918_0002'
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # Безопасно добавляем новые колонки для эквайринга в существующую таблицу menus
    op.add_column('menus', sa.Column('is_paid', sa.Boolean(), server_default='false', nullable=False))
    op.add_column('menus', sa.Column('payment_id', sa.String(length=100), nullable=True))
    op.add_column('menus', sa.Column('payment_system', sa.String(length=50), nullable=True))


def downgrade() -> None:
    # Откат миграции: удаление добавленных колонок
    op.drop_column('menus', 'payment_system')
    op.drop_column('menus', 'payment_id')
    op.drop_column('menus', 'is_paid')