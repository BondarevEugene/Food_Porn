"""create_app_settings_table

Revision ID: ffb74d9cb65b
Revises: 42fd32b02ed1
Create Date: 2026-09-26 11:58:49.091307
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'ffb74d9cb65b'
down_revision: Union[str, None] = '42fd32b02ed1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

