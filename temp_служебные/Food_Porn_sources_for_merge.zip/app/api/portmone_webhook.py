"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Portmone Payment Webhook Handler (FastAPI)
==========================================================
"""

from fastapi import APIRouter, Request
from aiogram import Bot
from app.config import get_settings
from app.database import async_session_maker
from app.database.repositories import CustomerRepository, MenuRepository
from app.bot.locales import get_text
from aiogram.types import FSInputFile
from pathlib import Path
from PIL import Image, ImageOps

router = APIRouter(prefix="/api/portmone", tags=["Portmone Webhook"])

@router.post("/webhook")
async def portmone_webhook(request: Request):
    """
    Приймає сповіщення від Portmone про статус платежу у форматі Form-data або JSON.
    """
    try:
        form_data = await request.form()
        data = dict(form_data)
    except Exception:
        try:
            data = await request.json()
        except Exception:
            data = {}

    # Portmone параметри зазвичай містять номер замовлення та статус
    shop_order_number = data.get("SHOP_ORDER_NUMBER") or data.get("shop_order_number")
    status = data.get("STATUS") or data.get("status")
    result = data.get("RESULT") or data.get("result")
    payment_id = data.get("PAYMENT_ID") or data.get("payment_id") or "PORTMONE_AUTO"

    # Перевірка успішності платежу (APPROVED або RESULT=1)
    is_success = (str(status).upper() == "APPROVED") or (str(result) == "1")

    if shop_order_number and shop_order_number.startswith("MANIFESTATION_"):
        try:
            user_id = int(shop_order_number.replace("MANIFESTATION_", ""))
        except ValueError:
            return {"status": "error", "message": "Invalid order ID format"}

        if is_success:
            settings = get_settings()
            bot = Bot(token=settings.bot_token)

            async with async_session_maker() as session:
                customer_repo = CustomerRepository(session)
                customer = await customer_repo.by_telegram_id(user_id)
                lang = customer.language if customer else "uk"

            # Надсилаємо сповіщення клієнту в Telegram
            try:
                success_text = (
                    "💳 <b>Оплату успішно підтверджено через Portmone!</b>\n\n"
                    "Ваш ексклюзивний пакет маніфестацій розблоковано. Готуємо файли..."
                ) if lang == "uk" else (
                    "💳 <b>Payment successfully confirmed via Portmone!</b>\n\n"
                    "Your exclusive manifestation package is unlocked. Preparing files..."
                )
                await bot.send_message(chat_id=user_id, text=success_text, parse_mode="HTML")
            except Exception as e:
                print(f"⚠️ Telegram notification error: {e}")
            finally:
                await bot.session.close()

            return {"status": "ok", "message": "Webhook processed successfully"}

    return {"status": "ignored", "message": "Unmatched order or unverified status"}
