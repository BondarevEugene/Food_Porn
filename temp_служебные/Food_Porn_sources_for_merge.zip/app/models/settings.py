"""
==========================================================
FOOD_PORN

Module: Application Settings Model
Layer: Database Models
==========================================================
"""

from sqlalchemy import Column, Integer, String, Text
from app.models.base import Base

class AppSetting(Base):
    __tablename__ = "app_settings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    key = Column(String(64), unique=True, index=True, nullable=False)
    value = Column(Text, nullable=True)
    description = Column(String(255), nullable=True)