"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS

Module: Application Bootstrap (main.py)
Layer: Application Core

Description: Точка входа в приложение. Инициализирует
настройки, базу данных, бота, диспетчер, фоновые процессы
и FastAPI вебхуки.
==========================================================
"""

from __future__ import annotations

import logging
import asyncio
from fastapi import FastAPI
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand

# Основные компоненты системы
from app.config import get_settings
from app.database.session import Database
from app.workers.menu_pipeline import MenuPipeline

# Роутери бота
from app.bot.handlers import start, registration, menu
from app.bot.handlers.wallpaper import router as wallpaper_router
from app.bot.handlers.admin import router as admin_router

# Вебхуки
from app.api.portmone_webhook import router as portmone_router

logger = logging.getLogger(__name__)

# Ініціалізація FastAPI додатку для вебхуків
app = FastAPI(title="Food_Porn & Old Money API", version="2.0")
app.include_router(portmone_router)


async def main() -> None:
    """Главная корутина запуска приложения."""

    # 1. Инициализация настроек и логирования
    settings = get_settings()
    settings.validate_runtime()
    settings.ensure_directories()

    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    logger.info("System Boot: Initializing Food_Porn & Old Money Ecosystem...")

    # 2. Инициализация инфраструктуры
    database = Database(settings)
    # Автоматичне створення таблиць (включно з app_settings), якщо їх ще немає
    async with database.engine.begin() as conn:
        from app.database.models import Base
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables verified & synchronized.")

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dispatcher = Dispatcher(storage=MemoryStorage())

    # 3. Инициализация фонового конвейера (Pipeline для FOOD_PORN)
    pipeline = MenuPipeline(
        bot=bot,
        settings=settings,
        session_factory=database.session_factory,
    )

    # 4. Внедрение зависимостей (Dependency Injection) в диспетчер
    dispatcher["settings"] = settings
    dispatcher["session_factory"] = database.session_factory
    dispatcher["pipeline"] = pipeline

    # 5. Регистрация всех маршрутов (роутеров) бота
    dispatcher.include_router(admin_router)
    dispatcher.include_router(start.router)
    dispatcher.include_router(registration.router)
    dispatcher.include_router(menu.router)
    dispatcher.include_router(wallpaper_router)  # Модуль AI Манифестаций

    # 6. Настройка командного меню бота
    await bot.set_my_commands(
        [
            BotCommand(command="start", description="Головне меню"),
            BotCommand(command="new", description="Створити новий сет / маніфестацію"),
            BotCommand(command="admin", description="Панель керування"),
        ]
    )

    # 7. Запуск процессов
    await pipeline.start()
    try:
        logger.info("System Ready: Bot is polling...")
        await dispatcher.start_polling(bot, allowed_updates=dispatcher.resolve_used_update_types())
    finally:
        # 8. Корректное завершение работы (Graceful Shutdown)
        logger.info("System Shutdown: Closing connections...")
        await pipeline.stop()
        await database.close()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Application stopped manually.")
