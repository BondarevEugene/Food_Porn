"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Admin Panel Handlers (Interactive Telegram Control)
==========================================================
"""

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.database import async_session_maker
from app.services.settings_service import (
    get_collage_price,
    get_setting,
    get_vip_users,
    set_setting,
)

router = Router(name="admin")


class AdminStates(StatesGroup):
    waiting_for_price = State()
    waiting_for_vip = State()


def get_admin_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="💰 Змінити ціну колажу", callback_data="admin_set_price")],
            [InlineKeyboardButton(text="👑 Керування VIP-користувачами", callback_data="admin_set_vip")],
            [InlineKeyboardButton(text="📊 Статистика системи", callback_data="admin_stats")],
            [InlineKeyboardButton(text="🏠 Головне меню", callback_data="back_to_main")],
        ]
    )


def get_back_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Назад в адмін-панель", callback_data="admin_home")],
            [InlineKeyboardButton(text="🏠 Головне меню", callback_data="back_to_main")],
        ]
    )


@router.message(F.text == "/admin")
async def admin_panel_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    async with async_session_maker() as session:
        price = await get_collage_price(session)
        vip_list = await get_vip_users(session)

    text = (
        "👑 <b>Панель керування екосистемою</b>\n\n"
        f"💰 Поточна ціна колажу: <b>{price} UAH</b>\n"
        f"👑 VIP користувачів у системі: <b>{len(vip_list)}</b>\n\n"
        "Оберіть необхідну дію нижче:"
    )
    await message.answer(text, reply_markup=get_admin_main_keyboard(), parse_mode="HTML")


@router.callback_query(F.data == "admin_home")
async def admin_home_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    async with async_session_maker() as session:
        price = await get_collage_price(session)
        vip_list = await get_vip_users(session)

    text = (
        "👑 <b>Панель керування екосистемою</b>\n\n"
        f"💰 Поточна ціна колажу: <b>{price} UAH</b>\n"
        f"👑 VIP користувачів у системі: <b>{len(vip_list)}</b>\n\n"
        "Оберіть необхідну дію нижче:"
    )
    await callback.message.edit_text(text, reply_markup=get_admin_main_keyboard(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin_set_price")
async def admin_set_price_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminStates.waiting_for_price)
    text = (
        "💰 <b>Введіть нову ціну колажу у гривнях (UAH):</b>\n\n"
        "Наприклад: <i>500</i> або <i>750</i>"
    )
    await callback.message.edit_text(text, reply_markup=get_back_keyboard(), parse_mode="HTML")
    await callback.answer()


@router.message(AdminStates.waiting_for_price, F.text)
async def admin_save_price(message: Message, state: FSMContext) -> None:
    try:
        new_price = int(message.text.strip())
        if new_price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("⚠️ Будь ласка, введіть коректне число (ціну у грн). Спробуйте ще раз:")
        return

    async with async_session_maker() as session:
        await set_setting(session, "collage_price_uah", str(new_price))

    await state.clear()
    text = f"✅ <b>Успішно!</b> Нова ціна колажу встановлена: <b>{new_price} UAH</b>."

    # Кнопка повернення
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔙 В адмін-панель", callback_data="admin_home")],
            [InlineKeyboardButton(text="🏠 Головне меню", callback_data="back_to_main")],
        ]
    )
    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")


@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery) -> None:
    text = (
        "📊 <b>Системна статистика</b>\n\n"
        "• База даних: Neon PostgreSQL (Підключено ✅)\n"
        "• Еквайринг: Portmone API (Активно ✅)\n"
        "• Рендерер ШІ: Replicate PuLID + OpenAI\n"
        "• Статус воркерів: Працюють у штатному режимі."
    )
    await callback.message.edit_text(text, reply_markup=get_back_keyboard(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "back_to_main")
async def back_to_main_menu(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    text = "🏠 Ви повернулися до головного меню. Натисніть /start або скористайтеся кнопками знизу."
    await callback.message.edit_text(text, parse_mode="HTML")
    await callback.answer()
