"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS

Module: Premium AI Manifestation Handlers (Replicate PuLID + OpenAI Fallback)
Layer: Telegram Interface (Old Money Aesthetic)
==========================================================
"""

import os
import json
import shutil
from pathlib import Path

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery, FSInputFile, Message,
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
)
from dotenv import load_dotenv
from PIL import Image, ImageOps, ImageDraw, ImageFont

from app.bot.states.wallpaper import WallpaperStates
from app.database import async_session_maker
from app.services.settings_service import get_vip_users, get_collage_price
from app.services.portmone import get_portmone_payment_url
from app.services.prompt_architect import PromptArchitect
from app.services.replicate_vision_board import ReplicateVisionBoardRenderer
from app.bot.locales import get_text
from app.config import (
    PRINT_SHOP_EMAIL, PRINT_SHOP_EMAIL_TEMPLATE,
    PRINT_POSTER_WIDTH_MM, PRINT_POSTER_HEIGHT_MM, PRINT_DPI
)

router = Router(name="wallpaper")


def get_payment_keyboard(order_id: int, price: int, currency: str, lang: str) -> InlineKeyboardMarkup:
    curr_label = "UAH" if currency == "UAH" else "USD"
    pay_url = get_portmone_payment_url(order_id=order_id, amount=price, currency=currency)
    pay_text = get_text(lang, "btn_pay", price=price, currency=curr_label)
    check_text = get_text(lang, "btn_check_pay")
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=pay_text, url=pay_url)],
            [InlineKeyboardButton(text=check_text, callback_data=f"check_pay_{order_id}")],
        ]
    )


def get_print_order_keyboard(lang: str) -> InlineKeyboardMarkup:
    print_text = get_text(lang, "btn_print")
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=print_text, callback_data="order_print_poster")]
        ]
    )


def generate_keyboard(lang: str) -> ReplyKeyboardMarkup:
    btn_text = get_text(lang, "btn_generate")
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=btn_text)]],
        resize_keyboard=True,
        one_time_keyboard=True
    )


def apply_heavy_watermark(image_path: Path) -> Path:
    """Накладає потужні захисні діагональні водяні знаки PREVIEW."""
    preview_path = image_path.parent / f"preview_heavy_wm_{image_path.name}"
    base = Image.open(image_path).convert("RGBA")

    width, height = base.size
    watermark_img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    w_draw = ImageDraw.Draw(watermark_img)

    try:
        font = ImageFont.truetype("arial.ttf", 54)
    except IOError:
        font = ImageFont.load_default()

    text = "🔒 PREVIEW • OLD MONEY VIP • NO RIGHTS"

    for y in range(-height, height * 2, 160):
        for x in range(-width, width * 2, 300):
            w_draw.text((x, y), text, fill=(255, 255, 255, 65), font=font)

    rotated_wm = watermark_img.rotate(35, resample=Image.Resampling.BICUBIC, center=(width / 2, height / 2))
    watermarked = Image.alpha_composite(base, rotated_wm).convert("RGB")
    watermarked.save(preview_path, "JPEG", quality=85)

    return preview_path


def prepare_device_wallpapers(original_path: Path, user_id: int) -> tuple[Path, Path]:
    """Адаптує єдиний вихідний арт під мобільний (9:16) та десктоп (16:9) формати."""
    img = Image.open(original_path).convert("RGB")

    # 1. Мобільна версія (9:16)
    mobile_img = ImageOps.fit(img, (1080, 1920), method=Image.Resampling.LANCZOS)
    mobile_path = original_path.parent / f"mobile_{user_id}.png"
    mobile_img.save(mobile_path, "PNG", quality=95)

    # 2. Десктопна версія (16:9)
    desktop_img = ImageOps.fit(img, (1920, 1080), method=Image.Resampling.LANCZOS)
    desktop_path = original_path.parent / f"desktop_{user_id}.png"
    desktop_img.save(desktop_path, "PNG", quality=95)

    return mobile_path, desktop_path


async def start_wallpaper_from_start(message: Message, state: FSMContext) -> None:
    await state.set_state(WallpaperStates.waiting_for_photos)
    upload_dir = Path("storage/uploads/wallpapers") / str(message.from_user.id)
    if upload_dir.exists():
        shutil.rmtree(upload_dir, ignore_errors=True)

    data = await state.get_data()
    lang = data.get("lang", "uk")

    text = get_text(lang, "intro")
    await message.answer(text, parse_mode="HTML", reply_markup=generate_keyboard(lang))


@router.message(WallpaperStates.waiting_for_photos, F.photo | F.document)
async def collect_photo(message: Message) -> None:
    if message.document and not message.document.mime_type.startswith("image/"):
        return

    file_id = message.photo[-1].file_id if message.photo else message.document.file_id
    file = await message.bot.get_file(file_id)

    upload_dir = Path("storage/uploads/wallpapers") / str(message.from_user.id)
    upload_dir.mkdir(parents=True, exist_ok=True)

    file_path = upload_dir / f"{message.message_id}.jpg"
    await message.bot.download_file(file.file_path, destination=file_path)


@router.message(WallpaperStates.waiting_for_photos, F.text & ~F.text.in_({"✨ Втілити в реальність", "✨ Manifest Reality"}))
async def collect_goals(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    goals = data.get("goals", [])
    new_goals = [line.strip() for line in message.text.split("\n") if line.strip()]
    goals.extend(new_goals)
    await state.update_data(goals=goals)


def prepare_user_source_image(user_id: int) -> Path | None:
    upload_dir = Path("storage/uploads/wallpapers") / str(user_id)
    if not upload_dir.exists():
        return None

    image_paths = sorted(list(upload_dir.glob("*.jpg")) + list(upload_dir.glob("*.png")))
    if not image_paths:
        return None

    processed_path = upload_dir / "prepared_source.png"

    try:
        images = [Image.open(p).convert("RGBA") for p in image_paths[:5]]
        if not images:
            return None

        canvas = Image.new("RGBA", (1024, 1024), (20, 18, 22, 255))
        padding = 12

        if len(images) == 5:
            w1, h1 = (1024 - padding * 4) // 3, 480
            for i in range(3):
                canvas.paste(ImageOps.fit(images[i], (w1, h1), method=Image.Resampling.LANCZOS), (padding + i * (w1 + padding), padding))
            w2, h2 = (1024 - padding * 3) // 2, 500
            for i in range(2):
                canvas.paste(ImageOps.fit(images[3 + i], (w2, h2), method=Image.Resampling.LANCZOS), (padding + i * (w2 + padding), padding + h1 + padding))
        else:
            w_box, h_box = (1024 - padding * 3) // 2, (1024 - padding * 3) // 2
            for i, img in enumerate(images[:4]):
                canvas.paste(ImageOps.fit(img, (w_box, h_box), method=Image.Resampling.LANCZOS), (padding + (i % 2) * (w_box + padding), padding + (i // 2) * (h_box + padding)))

        canvas.save(processed_path, "PNG")
        return processed_path
    except Exception:
        return None


@router.message(WallpaperStates.waiting_for_photos, F.text.in_({"✨ Втілити в реальність", "✨ Manifest Reality"}))
async def generate_wallpapers(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    goals = data.get("goals", [])
    currency = data.get("currency", "UAH")
    lang = data.get("lang", "uk")

    if not goals:
        await message.answer(get_text(lang, "missing_goals"))
        return

    wait_msg = await message.answer(
        get_text(lang, "generating"),
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove()
    )

    load_dotenv()
    replicate_token = os.getenv("REPLICATE_API_TOKEN", "REDACTED_REPLICATE_TOKEN")

    upload_dir = Path("storage/uploads/wallpapers") / str(message.from_user.id)
    photo_count = len(list(upload_dir.glob("*.jpg"))) + len(list(upload_dir.glob("*.png"))) if upload_dir.exists() else 1
    source_image_path = prepare_user_source_image(message.from_user.id)

    # Логуємо JSON-креслення через PromptArchitect
    blueprint_json = PromptArchitect.build_structured_blueprint(goals=goals, photo_count=photo_count)
    print(f"\n[PROMPT ARCHITECT BLUEPRINTS]:\n{json.dumps(blueprint_json, ensure_ascii=False, indent=2)}\n")

    try:
        # Використовуємо Replicate PuLID для ідеальної консистентності обличчя на колажі
        renderer = ReplicateVisionBoardRenderer(
            api_token=replicate_token,
            output_dir=Path(f"storage/wallpapers/{message.from_user.id}")
        )

        face_path = str(source_image_path) if (source_image_path and source_image_path.exists()) else str(upload_dir / "default.jpg")

        result_path = await renderer.build_board(
            user_id=message.from_user.id,
            goals=goals,
            face_image_path=face_path
        )

        class RenderResult:
            pass
        result = RenderResult()
        result.path = result_path

    except Exception as e:
        await wait_msg.delete()
        await message.answer(f"⚠️ Generation Error: {e}")
        return

    await wait_msg.delete()
    await state.update_data(last_render_path=str(result.path))

    async with async_session_maker() as session:
        vip_list = await get_vip_users(session)
        collage_price = await get_collage_price(session)

    user_is_vip = message.from_user.username in vip_list if message.from_user.username else False
    is_paid_order = data.get("is_paid", False)

    if user_is_vip or is_paid_order:
        mobile_path, desktop_path = prepare_device_wallpapers(result.path, message.from_user.id)
        await message.answer(get_text(lang, "vip_success"), parse_mode="HTML")
        await message.answer_photo(FSInputFile(str(mobile_path)), caption=get_text(lang, "mobile_caption"), parse_mode="HTML")
        await message.answer_photo(FSInputFile(str(desktop_path)), caption=get_text(lang, "desktop_caption"), parse_mode="HTML")
        await message.answer(get_text(lang, "print_offer"), reply_markup=get_print_order_keyboard(lang), parse_mode="HTML")
        await state.clear()
    else:
        preview_wm_path = apply_heavy_watermark(result.path)
        await message.answer_photo(FSInputFile(str(preview_wm_path)), caption=get_text(lang, "preview_caption"), parse_mode="HTML")

        price_to_show = collage_price if currency == "UAH" else int(collage_price / 41.5)
        await message.answer(
            get_text(lang, "concept_ready"),
            reply_markup=get_payment_keyboard(order_id=message.from_user.id, price=price_to_show, currency=currency, lang=lang),
            parse_mode="HTML"
        )


@router.callback_query(F.data == "order_print_poster")
async def process_print_order(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    user = callback.from_user
    lang = data.get("lang", "uk")

    email_body = PRINT_SHOP_EMAIL_TEMPLATE.format(
        user_id=user.id,
        username=user.username or "no_username",
        phone=data.get("phone", "Не вказано"),
        city="Kyiv",
        country="Ukraine",
        width=PRINT_POSTER_WIDTH_MM,
        height=PRINT_POSTER_HEIGHT_MM,
        dpi=PRINT_DPI,
        file_path=data.get("last_render_path", "storage/wallpapers/unknown.png")
    )

    print(f"\n[PRINT SHOP EMAIL DISPATCHED TO {PRINT_SHOP_EMAIL}]:\n{email_body}\n")

    await callback.message.answer(get_text(lang, "print_success"), parse_mode="HTML")
    await callback.answer()