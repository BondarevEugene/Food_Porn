"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Start & Onboarding Handlers (Dual Product Ecosystem with Back Navigation)
==========================================================
"""

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from app.bot.states.wallpaper import WallpaperStates
from app.database import async_session_maker
from app.database.repositories import CustomerRepository, MenuRepository
from app.database.models import Language

router = Router(name="start")


def get_phone_keyboard(lang: str = "uk") -> ReplyKeyboardMarkup:
    text = "📱 Поділитися номером телефону" if lang == "uk" else "📱 Share phone number"
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=text, request_contact=True)],
            [KeyboardButton(text="🏠 Головне меню")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def get_products_menu_keyboard() -> InlineKeyboardMarkup:
    """Головне меню вибору продуктів екосистеми."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🍷 FOOD_PORN • Гастрономічний сет", callback_data="prod_food_porn")],
            [InlineKeyboardButton(text="🗝 Old Money • Карта бажань / Заставки", callback_data="prod_manifestation")],
            [InlineKeyboardButton(text="👑 Панель керування (Адмін)", callback_data="admin_home")],
        ]
    )


@router.message(F.text.in_({"🏠 Головне меню", "/start", "⬅️ Назад до продуктів"}))
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    lang = "uk"

    async with async_session_maker() as session:
        customer_repo = CustomerRepository(session)
        customer = await customer_repo.by_telegram_id(message.from_user.id)

    if customer:
        text = (
            f"🗝 <b>Вітаю з поверненням, {customer.name}!</b> 🍷\n\n"
            "Оберіть продукт, який бажаєте створити сьогодні:"
        )
        await message.answer(text, parse_mode="HTML", reply_markup=ReplyKeyboardRemove())
        await message.answer("👇 <b>Головне меню екосистеми:</b>", reply_markup=get_products_menu_keyboard(), parse_mode="HTML")
    else:
        text = (
            "🗝 <b>Закритий Клуб • Food_Porn & Old Money Manifestations 🍷</b>\n\n"
            "Вітаю в ексклюзивній екосистемі генерації контенту.\n"
            "Для налаштування досвіду, будь ласка, поділіться вашим номером телефону:"
        )
        await message.answer(text, parse_mode="HTML", reply_markup=get_phone_keyboard(lang))


@router.callback_query(F.data == "back_to_products")
async def callback_back_to_products(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    text = "👇 <b>Головне меню екосистеми:</b>"
    try:
        await callback.message.edit_text(text, reply_markup=get_products_menu_keyboard(), parse_mode="HTML")
    except Exception:
        await callback.message.answer(text, reply_markup=get_products_menu_keyboard(), parse_mode="HTML")
    await callback.answer()


@router.message(F.contact)
async def receive_contact(message: Message, state: FSMContext, session_factory: async_sessionmaker[AsyncSession] = None) -> None:
    if message.from_user is None or message.contact is None:
        return

    phone = message.contact.phone_number
    lang = "uk"
    if not phone.startswith("+"):
        phone = "+" + phone

    currency = "UAH" if phone.startswith("+380") else "USD"

    async with async_session_maker() as session:
        customer_repo = CustomerRepository(session)
        await customer_repo.register(
            telegram_user_id=message.from_user.id,
            phone=phone,
            name=message.from_user.full_name or "Client",
            language=Language.UK if lang == "uk" else Language.EN,
            country="Ukraine" if currency == "UAH" else "International",
            city="Kyiv" if currency == "UAH" else "Global",
        )

    await state.update_data(phone=phone, currency=currency, lang=lang)

    text = (
        f"🇺🇦 <b>Локалізацію та валюту встановлено:</b> {'Українська (UAH)' if currency == 'UAH' else 'English (USD)'}.\n\n"
        "Оберіть продукт, який бажаєте створити сьогодні:"
    )
    await message.answer(text, parse_mode="HTML", reply_markup=ReplyKeyboardRemove())
    await message.answer("👇 <b>Меню екосистеми:</b>", reply_markup=get_products_menu_keyboard(), parse_mode="HTML")


@router.callback_query(F.data == "prod_manifestation")
async def start_manifestation_flow(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(WallpaperStates.waiting_for_photos)
    text = (
        "🗝 <b>Генератор Маніфестацій Old Money</b>\n\n"
        "Забудьте про шаблонні картинки. Штучний інтелект створить персональний безшовний шедевр із вашим обличчям.\n\n"
        "🍷 <b>Що потрібно:</b>\n"
        "1. Надішліть ваші фото (до 5 штук).\n"
        "2. Напишіть ваші цілі (кожна з нового рядка).\n"
        "Натисніть кнопку завершення, коли будете готові."
    )

    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="✨ Втілити в реальність")],
            [KeyboardButton(text="⬅️ Назад до меню")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )

    await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()


@router.message(WallpaperStates.waiting_for_photos, F.text == "⬅️ Назад до меню")
async def cancel_wallpaper_flow(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("👇 <b>Головне меню екосистеми:</b>", reply_markup=get_products_menu_keyboard(), parse_mode="HTML")


@router.callback_query(F.data == "prod_food_porn")
async def start_food_porn_flow(callback: CallbackQuery, state: FSMContext) -> None:
    async with async_session_maker() as session:
        customer_repo = CustomerRepository(session)
        customer = await customer_repo.by_telegram_id(callback.from_user.id)
        if customer:
            menu_repo = MenuRepository(session)
            menu = await menu_repo.create(customer)
            await state.update_data(menu_id=menu.id)

    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="🏠 Головне меню")]],
        resize_keyboard=True,
        one_time_keyboard=True
    )

    text = (
        "🍷 <b>FOOD_PORN • Елітний гастрономічний сет</b>\n\n"
        "Створюємо персональне ресторанне меню, рецепти та список покупок.\n"
        "Будь ласка, введіть назву першої страви або категорії:"
    )
    await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()