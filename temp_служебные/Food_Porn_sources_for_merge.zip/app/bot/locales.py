"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Localization Strings (UK / EN)
==========================================================
"""

STRINGS = {
    "uk": {
        "intro": (
            "🗝 <b>Закритий Генератор Маніфестацій</b>\n\n"
            "Забудьте про шаблонні картинки з інтернету. Штучний інтелект візьме "
            "<b>саме ваші завантажені фотографії</b> та переосмислить їх у безшовний шедевр Old Money.\n\n"
            "🍷 <b>Що потрібно від вас:</b>\n"
            "1. Надішліть ваші найкращі <b>фото</b> (до 5 штук).\n"
            "2. Напишіть ваші <b>цілі</b> (кожна з нового рядка).\n\n"
            "<i>Коли завершите — натисніть кнопку внизу.</i>"
        ),
        "btn_generate": "✨ Втілити в реальність",
        "missing_goals": "🖋 Ви забули вказати свої цілі. Напишіть хоча б кілька рядків.",
        "generating": "🕰 <i>Штучний інтелект створює ваш персональний арт-колаж у стилі Old Money... 🍷</i>",
        "vip_success": "⚜️ <b>Ваша реальність (VIP-доступ) успішно створена.</b>",
        "preview_caption": "📱 <i>Прев'ю маніфестації (Захищено водяними знаками)</i>",
        "concept_ready": (
            "⚜️ <b>Концепт успішно створено.</b>\n\n"
            "Для розблокування повного пакету (мобільна заставка, десктопні шпалери та доступ до друку) активуйте доступ."
        ),
        "btn_pay": "💳 Оплатити {price} {currency} через Portmone",
        "btn_check_pay": "🔄 Перевірити статус оплати",
        "mobile_caption": "📱 <i>Ексклюзивна заставка на мобільний (9:16)</i>",
        "desktop_caption": "💻 <i>Шпалери на робочий стіл ПК (16:9)</i>",
        "print_offer": (
            "📦 <b>Бажаєте перенести вашу маніфестацію у реальний світ?</b>\n\n"
            "Ми можемо надрукувати преміальний постер у розмірі 300x400 мм (300 DPI) на щільному арт-папері."
        ),
        "btn_print": "📦 Замовити друкований постер (300x400 мм)",
        "print_success": (
            "📦 <b>Замовлення на друкований постер успішно сформовано!</b>\n\n"
            "Партнер-типографія отримала специфікацію 300x400 мм (300 DPI) і зв'яжеться з вами для уточнення деталей."
        ),
    },
    "en": {
        "intro": (
            "🗝 <b>Private Manifestation Generator</b>\n\n"
            "Forget generic pictures from the web. Artificial intelligence will use "
            "<b>your exact uploaded photos</b> and reimagine them into a seamless Old Money masterpiece.\n\n"
            "🍷 <b>What is required from you:</b>\n"
            "1. Send your best <b>photos</b> (up to 5 images).\n"
            "2. Write down your <b>goals</b> (each on a new line).\n\n"
            "<i>When finished, click the button below.</i>"
        ),
        "btn_generate": "✨ Manifest Reality",
        "missing_goals": "🖋 You forgot to specify your goals. Please write at least a few lines.",
        "generating": "🕰 <i>Artificial intelligence is crafting your personal Old Money art collage... 🍷</i>",
        "vip_success": "⚜️ <b>Your reality (VIP Access) has been successfully created.</b>",
        "preview_caption": "📱 <i>Manifestation Preview (Protected by Watermarks)</i>",
        "concept_ready": (
            "⚜️ <b>Concept successfully created.</b>\n\n"
            "To unlock the full package (mobile wallpaper, desktop background, and print access), activate your pass."
        ),
        "btn_pay": "💳 Pay {price} {currency} via Portmone",
        "btn_check_pay": "🔄 Check Payment Status",
        "mobile_caption": "📱 <i>Exclusive Mobile Wallpaper (9:16)</i>",
        "desktop_caption": "💻 <i>Desktop Wallpaper (16:9)</i>",
        "print_offer": (
            "📦 <b>Would you like to bring your manifestation into the physical world?</b>\n\n"
            "We can print a premium poster sized 300x400 mm (300 DPI) on heavy art paper."
        ),
        "btn_print": "📦 Order Printed Poster (300x400 mm)",
        "print_success": (
            "📦 <b>Printed poster order successfully placed!</b>\n\n"
            "Our print partner has received the 300x400 mm (300 DPI) specs and will contact you for delivery details."
        ),
    }
}


def get_text(lang: str, key: str, **kwargs) -> str:
    lang_dict = STRINGS.get(lang, STRINGS["uk"])
    text = lang_dict.get(key, STRINGS["uk"].get(key, key))
    if kwargs:
        return text.format(**kwargs)
    return text
