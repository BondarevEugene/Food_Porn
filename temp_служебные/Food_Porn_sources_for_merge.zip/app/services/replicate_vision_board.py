"""Compose a five-scene vision board from the user's actual photographs.

The old Flux prompt ignored ``face_image_path`` and ``inspiration_images``.
This renderer keeps the public async API, uses every supplied image, blends
five scenes around the portrait and draws the exact supplied words with Pillow.
Requires: Pillow >= 10. Optional: a Cyrillic-capable serif font via font_regular
and font_bold. No Replicate call or API charge is made by this module.
"""
from __future__ import annotations

import asyncio
import logging
import os
import random
import re
import uuid
from pathlib import Path
from typing import Sequence

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

logger = logging.getLogger(__name__)

SIZES = {"9:16": (1080, 1920), "16:9": (1920, 1080), "reference": (1080, 2343)}
# The two examples are approximately 590 x 1280, hence the extra "reference" preset.


class ReplicateVisionBoardRenderer:
    """Backwards-compatible name for a deterministic, photo-based compositor."""

    def __init__(
        self,
        api_token: str | None = None,
        output_dir: Path | str = "data/generated/wallpapers",
        openai_api_key: str | None = None,
        font_regular: Path | str | None = None,
        font_bold: Path | str | None = None,
    ) -> None:
        # Keep the original constructor. Tokens are intentionally not read or exported.
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.font_regular = Path(font_regular) if font_regular else None
        self.font_bold = Path(font_bold) if font_bold else None

    async def build_board(
        self,
        user_id: int,
        goals: list[str],
        face_image_path: str,
        inspiration_images: Sequence[str] | None = None,
        title: str | None = None,
        aspect_ratio: str = "9:16",
    ) -> Path:
        return await self.generate_wallpaper(
            user_id, goals, face_image_path, aspect_ratio, inspiration_images, title
        )

    async def generate_wallpaper(
        self,
        user_id: int,
        goals: list[str],
        face_image_path: str,
        aspect_ratio: str = "9:16",
        inspiration_images: Sequence[str] | None = None,
        title: str | None = None,
        seed: int | None = None,
    ) -> Path:
        return await asyncio.to_thread(
            self._generate_sync,
            user_id, goals, face_image_path, aspect_ratio,
            inspiration_images, title, seed,
        )

    async def generate_from_telegram(
        self,
        *,
        user_id: int,
        goals: Sequence[str],
        photo_paths: Sequence[str | Path],
        aspect_ratio: str = "9:16",
        title: str | None = None,
        seed: int | None = None,
    ) -> Path:
        """The Food_Porn bot uploads five files total: portrait first, four scenes.

        Keep the order in which Telegram delivered the photographs. The fifth
        goal is the central heading when the bot did not collect a separate title.
        """
        if len(photo_paths) != 5:
            raise ValueError("Upload exactly five photos: portrait first, then four scenes")
        return await self.generate_wallpaper(
            user_id=user_id,
            goals=list(goals),
            face_image_path=str(photo_paths[0]),
            inspiration_images=[str(path) for path in photo_paths[1:]],
            aspect_ratio=aspect_ratio,
            title=title,
            seed=seed,
        )

    async def generate_all_formats(
        self,
        user_id: int,
        goals: list[str],
        face_image_path: str,
        inspiration_images: Sequence[str] | None = None,
        title: str | None = None,
        seed: int | None = None,
    ) -> dict[str, Path]:
        # Render sequentially to avoid two large in-memory canvases at once.
        mobile = await self.generate_wallpaper(
            user_id, goals, face_image_path, "9:16", inspiration_images, title, seed
        )
        desktop = await self.generate_wallpaper(
            user_id, goals, face_image_path, "16:9", inspiration_images, title, seed
        )
        return {"mobile": mobile, "desktop": desktop}

    def _generate_sync(
        self,
        user_id: int,
        goals: list[str],
        face_image_path: str,
        aspect_ratio: str,
        inspiration_images: Sequence[str] | None,
        title: str | None,
        seed: int | None,
    ) -> Path:
        if aspect_ratio not in SIZES:
            raise ValueError("aspect_ratio must be '9:16', '16:9' or 'reference'")
        if len(goals) != 5 or any(not isinstance(g, str) or not g.strip() for g in goals):
            raise ValueError("Pass exactly five non-empty goal phrases")
        if inspiration_images is None or len(inspiration_images) not in (4, 5):
            raise ValueError("Pass four scenes with a five-photo Telegram upload, or five with a separate portrait")
        face = self._load(face_image_path)
        scenes = [self._load(path) for path in inspiration_images]
        goals = [re.sub(r"\s+", " ", goal).strip() for goal in goals]
        if title is not None and not title.strip():
            raise ValueError("title cannot be blank")
        width, height = SIZES[aspect_ratio]
        rng = random.Random(seed if seed is not None else user_id)
        board = self._background(width, height, rng)
        layout = self._layout(aspect_ratio, len(scenes))
        for scene, bounds in zip(scenes, layout["scenes"]):
            board = self._blend_photo(board, scene, bounds, portrait=False)
        board = self._blend_photo(board, face, layout["hero"], portrait=True)
        board = self._finish_color(board)
        self._type(board, goals, title, layout)
        name = "mobile" if aspect_ratio == "9:16" else "desktop" if aspect_ratio == "16:9" else "reference"
        path = self.output_dir / f"manifestation_{user_id}_{name}.png"
        self._atomic_save(board, path, dpi=144)
        logger.info("Vision board saved: %s", path)
        return path

    @staticmethod
    def _load(path: str | Path) -> Image.Image:
        source = Path(path)
        if not source.is_file():
            raise FileNotFoundError(f"Photograph not found: {source}")
        with Image.open(source) as raw:
            raw = ImageOps.exif_transpose(raw)
            if raw.width < 300 or raw.height < 300:
                logger.warning("Low-resolution source image: %s (%sx%s)", source, raw.width, raw.height)
            return raw.convert("RGB").copy()

    @staticmethod
    def _layout(ratio: str, scene_count: int) -> dict:
        if scene_count == 4:
            if ratio == "16:9":
                return {
                    "scenes": [
                        (-.02, -.02, .38, .57), (.62, -.02, 1.02, .57),
                        (-.02, .49, .38, 1.02), (.62, .49, 1.02, 1.02),
                    ],
                    "hero": (.30, -.03, .70, .76),
                    "title": (.35, .72, .65, .92),
                    "labels": [
                        (.025, .10, .285, .25), (.715, .10, .975, .25),
                        (.025, .73, .285, .91), (.715, .73, .975, .91),
                        (.365, .92, .635, .99),
                    ],
                }
            return {
                "scenes": [
                    (-.03, -.025, .56, .55), (.44, -.025, 1.03, .55),
                    (-.03, .45, .56, 1.03), (.44, .45, 1.03, 1.03),
                ],
                "hero": (.16, .18, .84, .745),
                "title": (.15, .56, .85, .74),
                "labels": [
                    (.035, .105, .32, .22), (.68, .105, .965, .22),
                    (.035, .83, .32, .955), (.68, .83, .965, .955),
                    (.32, .75, .68, .835),
                ],
            }
        if ratio == "16:9":
            return {
                "scenes": [
                    (0.00, 0.00, .34, .55), (.66, 0.00, 1.00, .55),
                    (0.00, .44, .37, 1.00), (.63, .44, 1.00, 1.00),
                    (.32, .67, .69, 1.00),
                ],
                "hero": (.31, -.03, .70, .76),
                "title": (.35, .72, .65, .93),
                "labels": [
                    (.035, .075, .29, .24), (.72, .075, .965, .24),
                    (.03, .72, .29, .91), (.72, .72, .965, .91),
                    (.365, .91, .635, .985),
                ],
            }
        return {
            "scenes": [
                (-.03, -.025, .56, .32), (.46, -.025, 1.03, .32),
                (-.04, .29, .51, .73), (.53, .29, 1.04, .73),
                (-.025, .71, 1.025, 1.03),
            ],
            "hero": (.185, .14, .815, .605),
            "title": (.17, .565, .83, .735),
            "labels": [
                (.035, .115, .315, .215), (.70, .115, .965, .215),
                (.035, .455, .31, .565), (.705, .455, .965, .565),
                (.07, .84, .48, .955),
            ],
        }

    @staticmethod
    def _background(w: int, h: int, rng: random.Random) -> Image.Image:
        img = Image.new("RGB", (w, h))
        d = ImageDraw.Draw(img)
        for y in range(h):
            t = y / h
            d.line((0, y, w, y), fill=(int(139-39*t), int(112-34*t), int(86-26*t)))
        glows = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        g = ImageDraw.Draw(glows)
        for _ in range(15):
            x, y = rng.randrange(w), rng.randrange(h)
            r = rng.randrange(max(16, w//45), max(18, w//12))
            g.ellipse((x-r, y-r, x+r, y+r), fill=(255, 221, 171, rng.randrange(20, 52)))
        glows = glows.filter(ImageFilter.GaussianBlur(max(20, w//32)))
        return Image.alpha_composite(img.convert("RGBA"), glows).convert("RGB")

    @staticmethod
    def _blend_photo(
        canvas: Image.Image, source: Image.Image,
        bounds: tuple[float, float, float, float], *, portrait: bool,
    ) -> Image.Image:
        w, h = canvas.size
        x0, y0, x1, y1 = (round(bounds[0]*w), round(bounds[1]*h), round(bounds[2]*w), round(bounds[3]*h))
        bw, bh = x1-x0, y1-y0
        # Preserve source proportions. Portrait crop is biased slightly upward.
        image = ImageOps.fit(
            source, (bw, bh), method=Image.Resampling.LANCZOS,
            centering=(.5, .32 if portrait else .5),
        )
        image = ImageEnhance.Color(image).enhance(.81)
        image = ImageEnhance.Contrast(image).enhance(1.035)
        warm = Image.new("RGB", image.size, (201, 161, 119))
        image = Image.blend(image, warm, .075)
        # A filled inner area with broad, transparent edges makes photos merge.
        mask = Image.new("L", (bw, bh), 0)
        md = ImageDraw.Draw(mask)
        if portrait:
            inset_x, inset_y = int(bw*.09), int(bh*.055)
            md.ellipse((inset_x, inset_y, bw-inset_x, bh+int(bh*.17)), fill=255)
            radius = int(min(bw, bh)*.085)
        else:
            inset_x, inset_y = int(bw*.042), int(bh*.055)
            md.rounded_rectangle(
                (inset_x, inset_y, bw-inset_x, bh-inset_y),
                radius=int(min(bw, bh)*.14), fill=245,
            )
            radius = int(min(bw, bh)*.105)
        mask = mask.filter(ImageFilter.GaussianBlur(max(12, radius)))
        if portrait:
            # Release the bottom of the portrait into the title area.
            fade = Image.new("L", (1, bh), 255)
            fd = ImageDraw.Draw(fade)
            start = int(bh*.76)
            for y in range(start, bh):
                fd.point((0, y), fill=int(255*(bh-y)/max(1, bh-start)))
            mask = ImageChops.multiply(mask, fade.resize((bw, bh)))
        # PIL clips off-canvas layers, but crop explicitly for old Pillow versions.
        left, top = max(0, x0), max(0, y0)
        right, bottom = min(w, x1), min(h, y1)
        if right > left and bottom > top:
            region = (left-x0, top-y0, right-x0, bottom-y0)
            canvas.paste(image.crop(region), (left, top), mask.crop(region))
        return canvas

    @staticmethod
    def _finish_color(image: Image.Image) -> Image.Image:
        w, h = image.size
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        # Small darkening at top/bottom makes every source photo feel cohesive.
        for y in range(h):
            edge = max(0, 1-y/(h*.16), (y/h-.83)/.17)
            alpha = int(83*max(0, min(1, edge)))
            if alpha:
                ld.line((0, y, w, y), fill=(23, 13, 9, alpha))
        return Image.alpha_composite(image.convert("RGBA"), layer).convert("RGB")

    def _font(self, size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
        configured = self.font_bold if bold else self.font_regular
        candidates = [
            configured,
            Path("C:/Windows/Fonts/georgiab.ttf" if bold else "C:/Windows/Fonts/georgia.ttf"),
            Path("C:/Windows/Fonts/timesbd.ttf" if bold else "C:/Windows/Fonts/times.ttf"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"),
            Path("/usr/share/fonts/truetype/liberation2/LiberationSerif-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf"),
        ]
        for p in candidates:
            if p is not None and p.is_file():
                try:
                    return ImageFont.truetype(str(p), size)
                except OSError:
                    pass
        raise RuntimeError("Install DejaVu Serif, or pass font_regular/font_bold with Cyrillic glyphs")

    @staticmethod
    def _wrap(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_w: int) -> str:
        rows: list[str] = []
        row = ""
        for word in text.split():
            candidate = f"{row} {word}".strip()
            if row and draw.textlength(candidate, font=font) > max_w:
                rows.append(row)
                row = word
            else:
                row = candidate
        if row:
            rows.append(row)
        return "\n".join(rows)

    def _text_in_box(
        self, layer: Image.Image, text: str, bounds: tuple[float, float, float, float],
        *, title: bool = False, align: str = "center",
    ) -> None:
        w, h = layer.size
        x0, y0, x1, y1 = (round(bounds[0]*w), round(bounds[1]*h), round(bounds[2]*w), round(bounds[3]*h))
        box_w, box_h = x1-x0, y1-y0
        draw = ImageDraw.Draw(layer)
        max_size = round(w*(.047 if title else .030)) if h > w else round(h*(.048 if title else .027))
        min_size = 18 if title else 15
        for size in range(max_size, min_size-1, -1):
            font = self._font(size, bold=title)
            lines = self._wrap(draw, text, font, box_w-12)
            spacing = round(size*.24)
            bbox = draw.multiline_textbbox((0, 0), lines, font=font, spacing=spacing, align=align)
            tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
            if tw <= box_w-8 and th <= box_h-8:
                break
        else:
            raise ValueError(f"Text does not fit in its scene: {text!r}. Shorten the phrase.")
        x = x0+(box_w-tw)//2 if align == "center" else x0
        y = y0+(box_h-th)//2-bbox[1]
        # Dark soft halo improves readability on white clothing and bright skies.
        halo = Image.new("RGBA", layer.size, (0, 0, 0, 0))
        hd = ImageDraw.Draw(halo)
        hd.multiline_text((x, y), lines, font=font, spacing=spacing, align=align,
                          fill=(15, 11, 9, 220), stroke_width=max(3, size//9), stroke_fill=(15, 11, 9, 185))
        layer.alpha_composite(halo.filter(ImageFilter.GaussianBlur(max(4, size//5))))
        draw = ImageDraw.Draw(layer)
        draw.multiline_text((x, y), lines, font=font, spacing=spacing, align=align,
                            fill=(251, 240, 218, 255), stroke_width=max(1, size//25), stroke_fill=(57, 38, 24, 200))

    def _type(self, image: Image.Image, goals: list[str], title: str | None, layout: dict) -> None:
        w, h = image.size
        # The bot supplies every visible word. Without an extra title, the
        # fifth user goal takes the large central position, appearing once.
        heading = title if title is not None else goals[4]
        scene_goals = goals if title is not None else goals[:4]
        tx0, ty0, tx1, ty1 = layout["title"]
        ribbon = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        rd = ImageDraw.Draw(ribbon)
        rd.ellipse((int((tx0-.15)*w), int((ty0-.07)*h), int((tx1+.15)*w), int((ty1+.06)*h)),
                   fill=(42, 27, 18, 125))
        image.paste(Image.alpha_composite(image.convert("RGBA"), ribbon.filter(
            ImageFilter.GaussianBlur(int(w*.04)))).convert("RGB"))
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        heading = re.sub(r"\s+", " ", heading).strip()
        self._text_in_box(overlay, heading, layout["title"], title=True)
        for goal, box in zip(scene_goals, layout["labels"]):
            self._text_in_box(overlay, goal, box)
        image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))

    @staticmethod
    def _atomic_save(image: Image.Image, path: Path, *, dpi: int) -> None:
        temp = path.with_name(f".{path.stem}.{uuid.uuid4().hex}.tmp.png")
        try:
            image.save(temp, format="PNG", dpi=(dpi, dpi), optimize=True)
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)

    async def prepare_print_poster(
        self,
        user_id: int,
        source_image_path: str,
        width_mm: int = 300,
        height_mm: int = 400,
        dpi: int = 300,
        bleed_mm: int = 3,
    ) -> Path:
        return await asyncio.to_thread(
            self._print_sync, user_id, source_image_path, width_mm, height_mm, dpi, bleed_mm
        )

    def _print_sync(
        self, user_id: int, source: str, width_mm: int, height_mm: int,
        dpi: int, bleed_mm: int,
    ) -> Path:
        if min(width_mm, height_mm, dpi) <= 0 or bleed_mm < 0:
            raise ValueError("Print dimensions and DPI must be positive; bleed must be nonnegative")
        if width_mm > 1000 or height_mm > 1000 or dpi > 600:
            raise ValueError("Print size is too large for in-memory rendering")
        image = self._load(source)
        px = lambda mm: round(mm/25.4*dpi)
        content_size = (px(width_mm), px(height_mm))
        bleed = px(bleed_mm)
        if content_size[0]*content_size[1] > 70_000_000:
            raise ValueError("Print image exceeds 70 megapixels")
        # Keep all user text visible if the source and paper have different ratios.
        background = ImageOps.fit(image, content_size, method=Image.Resampling.LANCZOS)
        background = background.filter(ImageFilter.GaussianBlur(max(8, dpi//12)))
        foreground = ImageOps.contain(image, content_size, method=Image.Resampling.LANCZOS)
        background.paste(foreground, ((content_size[0]-foreground.width)//2,
                                      (content_size[1]-foreground.height)//2))
        if bleed:
            cw, ch = content_size
            expanded = Image.new("RGB", (cw+2*bleed, ch+2*bleed))
            expanded.paste(background, (bleed, bleed))
            # Repeat the outermost pixel row/column into the printer's bleed.
            expanded.paste(background.crop((0, 0, 1, ch)).resize((bleed, ch)), (0, bleed))
            expanded.paste(background.crop((cw-1, 0, cw, ch)).resize((bleed, ch)), (bleed+cw, bleed))
            expanded.paste(background.crop((0, 0, cw, 1)).resize((cw, bleed)), (bleed, 0))
            expanded.paste(background.crop((0, ch-1, cw, ch)).resize((cw, bleed)), (bleed, bleed+ch))
            for x, y, color in (
                (0, 0, background.getpixel((0, 0))),
                (bleed+cw, 0, background.getpixel((cw-1, 0))),
                (0, bleed+ch, background.getpixel((0, ch-1))),
                (bleed+cw, bleed+ch, background.getpixel((cw-1, ch-1))),
            ):
                expanded.paste(Image.new("RGB", (bleed, bleed), color), (x, y))
            background = expanded
        path = self.output_dir / f"poster_{user_id}_{width_mm}x{height_mm}mm_{dpi}dpi.png"
        if image.width < content_size[0] or image.height < content_size[1]:
            logger.warning("Print file is upscaled from %sx%s; DPI metadata cannot create missing detail", *image.size)
        self._atomic_save(background, path, dpi=dpi)
        return path
