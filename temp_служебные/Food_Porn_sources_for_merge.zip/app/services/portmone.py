"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Portmone Payment Gateway Service
==========================================================
"""

from urllib.parse import urlencode
from app.config import get_settings


def get_portmone_payment_url(order_id: int, amount: int, currency: str = "UAH") -> str:
    """
    Формує посилання на оплату через шлюз Portmone з урахуванням суми,
    валюти та унікального номеру замовлення (order_id).
    """
    settings = get_settings()

    # Базовий шлюз або тестова сторінка
    base_url = "https://www.portmone.com.ua/gateway/"

    params = {
        "payee_id": settings.portmone_payee_id,
        "shop_order_number": f"MANIFESTATION_{order_id}",
        "bill_amount": f"{amount:.2f}",
        "bill_currency": currency,
        "description": f"Old Money Manifestation Original HQ (Order #{order_id})",
        "lang": "uk" if currency == "UAH" else "en",
    }

    # Якщо credentials ще не налаштовані, повертаємо дефолтне посилання з документації
    if settings.portmone_payee_id == "replace_me":
        return settings.portmone_gateway_url

    return f"{base_url}?{urlencode(params)}"
