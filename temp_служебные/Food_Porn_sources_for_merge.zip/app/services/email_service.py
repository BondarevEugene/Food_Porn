"""
==========================================================
FOOD_PORN & OLD MONEY MANIFESTATIONS
Module: Real Email Dispatcher (SMTP)
==========================================================
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.config import get_settings


async def send_printshop_order_email(email_body: str) -> bool:
    settings = get_settings()

    # Якщо пошта не налаштована, просто логуємо
    if settings.smtp_user == "your_email@gmail.com" or not settings.smtp_password:
        print(f"\n[SMTP MOCK DISPATCH]:\n{email_body}\n")
        return True

    try:
        msg = MIMEMultipart()
        msg["From"] = settings.smtp_user
        msg["To"] = settings.printshop_email
        msg["Subject"] = "📦 New Poster Print Order [Old Money Manifestations]"

        msg.attach(MIMEText(email_body, "plain", "utf-8"))

        # Підключаємося до SMTP через SSL (порт 465)
        server = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port)
        server.login(settings.smtp_user, settings.smtp_password.get_secret_value())
        server.sendmail(settings.smtp_user, settings.printshop_email, msg.as_string())
        server.quit()

        return True
    except Exception as e:
        print(f"⚠️ SMTP Dispatch Error: {e}")
        return False
